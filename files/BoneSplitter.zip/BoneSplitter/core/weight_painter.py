# core/weight_painter.py
# ウェイトペイントロジック

import bpy
from mathutils import Vector
from typing import List
import math


class WeightPainter:
    """選択した頂点のみにウェイトを設定"""
    
    def __init__(self, mesh_obj, armature):
        self.mesh_obj = mesh_obj
        self.armature = armature
        self.mesh = mesh_obj.data
        
    def paint_bones(
        self,
        bone_names: List[str],
        vertex_indices: List[int],
        radius: float = 0.02,
        max_influences: int = 2,
        distance_exponent: float = 2.0,
    ):
        """指定された頂点にのみウェイトを設定"""
        if not bone_names or not vertex_indices:
            return
        
        # 頂点グループを作成
        for bone_name in bone_names:
            if bone_name not in self.mesh_obj.vertex_groups:
                self.mesh_obj.vertex_groups.new(name=bone_name)
        
        # ボーン情報を事前計算
        bone_data = self._precompute_bone_data(bone_names)
        
        # 各頂点のウェイトを計算
        for vert_idx in vertex_indices:
            vert = self.mesh.vertices[vert_idx]
            vert_world = self.mesh_obj.matrix_world @ vert.co
            
            weights = self._compute_vertex_weights(
                vert_world,
                bone_data,
                radius,
                max_influences,
                distance_exponent,
            )
            
            # ウェイトを適用
            for bone_name, weight in weights.items():
                if weight > 0.001:
                    vg = self.mesh_obj.vertex_groups[bone_name]
                    vg.add([vert_idx], weight, 'REPLACE')
    
    def _precompute_bone_data(self, bone_names: List[str]) -> List[dict]:
        """ボーン情報を事前計算"""
        bone_data = []
        
        for bone_name in bone_names:
            bone = self.armature.data.bones.get(bone_name)
            if not bone:
                continue
            
            head = self.armature.matrix_world @ bone.head_local
            tail = self.armature.matrix_world @ bone.tail_local
            
            bone_data.append({
                'name': bone_name,
                'head': head,
                'tail': tail,
                'center': (head + tail) / 2,
                'length': (tail - head).length,
                'direction': (tail - head).normalized(),
            })
        
        return bone_data
    
    def _compute_vertex_weights(
        self,
        vert_pos: Vector,
        bone_data: List[dict],
        radius: float,
        max_influences: int,
        distance_exponent: float,
    ) -> dict:
        """頂点のウェイトを計算"""
        weights = {}
        total = 0
        
        for bd in bone_data:
            # ボーン軸への最近接点を計算
            bone_vec = bd['tail'] - bd['head']
            to_vert = vert_pos - bd['head']
            
            t = max(0, min(1, to_vert.dot(bone_vec) / bone_vec.length_squared))
            closest = bd['head'] + bone_vec * t
            
            dist = (vert_pos - closest).length
            
            # ガウシアン減衰
            sigma = max(radius, bd['length'] * 0.25)
            weight = math.exp(-(dist / sigma) ** distance_exponent)
            
            weights[bd['name']] = weight
            total += weight
        
        # 上位N本のみ採用
        if weights:
            top = sorted(weights.items(), key=lambda kv: kv[1], reverse=True)[:max_influences]
            total = sum(w for _, w in top)
            if total > 0:
                weights = {name: w / total for name, w in top}
            else:
                weights = {name: 0 for name, _ in top}
        
        return weights


def cleanup_weights(mesh_obj, threshold: float = 0.01):
    """微小ウェイトを削除して正規化"""
    mesh = mesh_obj.data
    
    for vert in mesh.vertices:
        valid_weights = []
        
        # 有効なウェイトを収集
        for vg in mesh_obj.vertex_groups:
            try:
                w = vg.weight(vert.index)
                if w > threshold:
                    valid_weights.append((vg, w))
            except RuntimeError:
                pass
        
        # 正規化して再適用
        total = sum(w for _, w in valid_weights)
        if total > 0:
            for vg, w in valid_weights:
                vg.add([vert.index], w / total, 'REPLACE')
