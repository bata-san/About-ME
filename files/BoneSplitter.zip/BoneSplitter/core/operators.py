# core/operators.py
# オペレーター定義

import bpy
from bpy.types import Operator

from . import hair_analyzer
from . import bone_generator
from . import weight_painter


class BONE_OT_generate_hair_bones(Operator):
    """選択した髪の束にボーンを生成"""
    bl_idname = "bonesplitter.generate"
    bl_label = "ボーン生成"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'EDIT'
    
    def execute(self, context):
        settings = context.scene.bonesplitter
        mesh_obj = context.active_object
        
        # アーマチュアを取得
        armature = bone_generator.find_armature_for_mesh(mesh_obj)
        if not armature:
            self.report({'ERROR'}, "アーマチュアが見つかりません")
            return {'CANCELLED'}
        
        # 選択された頂点を取得
        vert_indices = hair_analyzer.get_selected_vert_indices(mesh_obj)
        if len(vert_indices) < 3:
            self.report({'ERROR'}, "髪の束を選択してください (Ctrl+L)")
            return {'CANCELLED'}
        
        # 髪の束を解析
        analyzer = hair_analyzer.HairStrandAnalyzer(mesh_obj, vert_indices)
        bone_positions = analyzer.compute_bone_positions(settings.bone_count, settings.smoothing)
        side = analyzer.detect_side()
        
        # 選択状態を保存してオブジェクトモードへ
        saved_indices = hair_analyzer.save_selection_to_object_mode(mesh_obj)
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # ボーン名を生成
        side_token = side.replace('.', '') or "C"
        hair_number = f"{settings.chain_number:02d}"
        base_prefix = settings.prefix
        
        # 親ボーンを決定
        parent = settings.parent_bone or bone_generator.find_head_bone(armature)
        
        # ボーン生成
        generator = bone_generator.BoneChainGenerator(armature)
        created_bones = generator.create_chain(
            bone_positions,
            base_prefix,
            side_token,
            hair_number,
            parent,
        )
        
        if not created_bones:
            self.report({'ERROR'}, "ボーン生成に失敗")
            return {'CANCELLED'}
        
        # ウェイトペイント
        if settings.auto_weight:
            painter = weight_painter.WeightPainter(mesh_obj, armature)
            painter.paint_bones(
                created_bones,
                saved_indices,
                settings.weight_radius,
                settings.max_influences,
                settings.distance_exponent,
            )
        
        # チェーン番号をインクリメント
        settings.chain_number += 1
        
        # 編集モードに戻る
        bpy.ops.object.mode_set(mode='EDIT')
        
        self.report({'INFO'}, f"生成完了: {base_prefix}.{side_token}.{hair_number} ({len(created_bones)}ボーン)")
        return {'FINISHED'}


class BONE_OT_reset_number(Operator):
    """チェーン番号をリセット"""
    bl_idname = "bonesplitter.reset_number"
    bl_label = "番号リセット"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.bonesplitter.chain_number = 1
        return {'FINISHED'}


class BONE_OT_detect_head(Operator):
    """頭ボーンを自動検出"""
    bl_idname = "bonesplitter.detect_head"
    bl_label = "頭ボーン検出"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # アーマチュアを探す
        armature = None
        obj = context.active_object
        
        if obj and obj.type == 'MESH':
            armature = bone_generator.find_armature_for_mesh(obj)
        
        if not armature:
            for o in context.scene.objects:
                if o.type == 'ARMATURE':
                    armature = o
                    break
        
        if not armature:
            self.report({'ERROR'}, "アーマチュアが見つかりません")
            return {'CANCELLED'}
        
        head = bone_generator.find_head_bone(armature)
        if head:
            context.scene.bonesplitter.parent_bone = head
            self.report({'INFO'}, f"検出: {head}")
        else:
            self.report({'WARNING'}, "頭ボーンが見つかりません")
        
        return {'FINISHED'}


class BONE_OT_mirror(Operator):
    """選択したボーンをミラー"""
    bl_idname = "bonesplitter.mirror"
    bl_label = "ボーンをミラー"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'ARMATURE'
    
    def execute(self, context):
        armature = context.active_object
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        selected = [b for b in armature.data.edit_bones if b.select]
        if not selected:
            self.report({'ERROR'}, "ボーンを選択してください")
            bpy.ops.object.mode_set(mode='OBJECT')
            return {'CANCELLED'}
        
        for bone in selected:
            # 名前変換
            if ".L" in bone.name:
                new_name = bone.name.replace(".L", ".R")
            elif ".R" in bone.name:
                new_name = bone.name.replace(".R", ".L")
            else:
                new_name = bone.name + ".mirror"
            
            # ミラーボーン作成
            mirror = armature.data.edit_bones.new(new_name)
            mirror.head.x = -bone.head.x
            mirror.head.y = bone.head.y
            mirror.head.z = bone.head.z
            mirror.tail.x = -bone.tail.x
            mirror.tail.y = bone.tail.y
            mirror.tail.z = bone.tail.z
            mirror.roll = -bone.roll
            
            # 親を設定
            if bone.parent:
                pname = bone.parent.name
                if ".L" in pname:
                    mirror_pname = pname.replace(".L", ".R")
                elif ".R" in pname:
                    mirror_pname = pname.replace(".R", ".L")
                else:
                    mirror_pname = pname
                
                mp = armature.data.edit_bones.get(mirror_pname)
                if mp:
                    mirror.parent = mp
                else:
                    mirror.parent = bone.parent
                
                mirror.use_connect = bone.use_connect
        
        bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, f"{len(selected)}個のボーンをミラー")
        return {'FINISHED'}


class BONE_OT_cleanup_weights(Operator):
    """ウェイトをクリーンアップ"""
    bl_idname = "bonesplitter.cleanup_weights"
    bl_label = "ウェイトクリーンアップ"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'
    
    def execute(self, context):
        weight_painter.cleanup_weights(context.active_object)
        self.report({'INFO'}, "クリーンアップ完了")
        return {'FINISHED'}


CLASSES = [
    BONE_OT_generate_hair_bones,
    BONE_OT_reset_number,
    BONE_OT_detect_head,
    BONE_OT_mirror,
    BONE_OT_cleanup_weights,
]
