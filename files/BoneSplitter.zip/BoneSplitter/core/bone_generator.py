# core/bone_generator.py
# ボーン生成ロジック

import bpy
from mathutils import Vector
from typing import List, Optional


class BoneChainGenerator:
    """ボーンチェーンを生成"""
    
    def __init__(self, armature):
        self.armature = armature
        
    def create_chain(
        self,
        positions: List[Vector],
        base_prefix: str,
        side_token: str,
        hair_number: str,
        parent_bone_name: Optional[str] = None,
    ) -> List[str]:
        """ボーンチェーンを作成（cc_hear.<side>.<hairNo>.<boneNo>）"""
        if len(positions) < 2:
            return []
        
        # アーマチュアをアクティブに
        bpy.context.view_layer.objects.active = self.armature
        bpy.ops.object.mode_set(mode='EDIT')
        
        edit_bones = self.armature.data.edit_bones
        inv_matrix = self.armature.matrix_world.inverted()
        
        created_bones = []
        prev_bone = None
        
        for i in range(len(positions) - 1):
            # ボーン名: base.side.hairNo.boneNo
            bone_name = f"{base_prefix}.{side_token}.{hair_number}.{i+1:03d}"
            
            bone = edit_bones.new(bone_name)
            bone.head = inv_matrix @ positions[i]
            bone.tail = inv_matrix @ positions[i + 1]
            
            # 親を設定
            if i == 0:
                # 最初のボーンは指定された親に接続
                if parent_bone_name:
                    parent = edit_bones.get(parent_bone_name)
                    if parent:
                        bone.parent = parent
                        bone.use_connect = False
            else:
                # 2番目以降は前のボーンに接続
                bone.parent = prev_bone
                bone.use_connect = True
            
            prev_bone = bone
            created_bones.append(bone_name)
        
        bpy.ops.object.mode_set(mode='OBJECT')
        return created_bones


def find_armature_for_mesh(mesh_obj):
    """メッシュに関連付けられたアーマチュアを取得"""
    for mod in mesh_obj.modifiers:
        if mod.type == 'ARMATURE' and mod.object:
            return mod.object
    return None


def find_head_bone(armature) -> Optional[str]:
    """頭ボーンを自動検出"""
    candidates = [
        'head', 'Head', 'HEAD',
        'head.x', 'c_head.x', 'c_head',  # Auto-rig pro
        'Head_M',  # Mixamo
        'J_Bip_C_Head',  # VRM
    ]
    
    for bone in armature.data.bones:
        # 完全一致
        if bone.name in candidates:
            return bone.name
        # 部分一致（最後の手段）
        if 'head' in bone.name.lower() and 'headset' not in bone.name.lower():
            return bone.name
    
    return None
