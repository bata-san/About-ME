# core/panels.py
# UIパネル定義

import bpy
from bpy.types import Panel


class BONE_PT_main(Panel):
    """メインパネル"""
    bl_label = "BoneSplitter"
    bl_idname = "BONE_PT_bonesplitter_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BoneSplitter'
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.bonesplitter
        
        # === メイン機能 ===
        main_box = layout.box()
        main_box.label(text="髪ボーン生成", icon='BONE_DATA')
        
        col = main_box.column(align=True)
        
        # ボーン数
        col.prop(settings, "bone_count", text="ボーン数")
        col.prop(settings, "smoothing", text="スムージング")
        col.separator()
        
        # 生成ボタン（大きく）
        col.scale_y = 1.5
        col.operator("bonesplitter.generate", text="選択した束に生成", icon='ADD')
        col.scale_y = 1.0
        
        # 使い方ヒント
        hint_box = main_box.box()
        hint_box.scale_y = 0.7
        hint_col = hint_box.column(align=True)
        hint_col.label(text="手順:", icon='INFO')
        hint_col.label(text="  1. 髪メッシュを編集モードに")
        hint_col.label(text="  2. 頂点を1つ選択 → Ctrl+L")
        hint_col.label(text="  3. ボタンをクリック")
        hint_col.label(text="命名: cc_hear.<L/R/C>.<髪番号>.<ボーン番号>")


class BONE_PT_settings(Panel):
    """設定パネル"""
    bl_label = "設定"
    bl_idname = "BONE_PT_bonesplitter_settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BoneSplitter'
    bl_parent_id = "BONE_PT_bonesplitter_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.bonesplitter
        
        # 命名設定
        box = layout.box()
        box.label(text="命名", icon='FONT_DATA')
        
        col = box.column(align=True)
        col.prop(settings, "prefix", text="プレフィックス")
        
        row = col.row(align=True)
        row.prop(settings, "chain_number", text="番号")
        row.operator("bonesplitter.reset_number", text="", icon='FILE_REFRESH')
        
        # 親ボーン
        box = layout.box()
        box.label(text="親ボーン", icon='BONE_DATA')
        
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(settings, "parent_bone", text="")
        row.operator("bonesplitter.detect_head", text="", icon='VIEWZOOM')
        
        # ウェイト設定
        box = layout.box()
        box.label(text="ウェイト", icon='MOD_VERTEX_WEIGHT')
        
        col = box.column(align=True)
        col.prop(settings, "auto_weight")
        if settings.auto_weight:
            col.prop(settings, "weight_radius", text="影響半径")
            col.prop(settings, "max_influences", text="最大影響")
            col.prop(settings, "distance_exponent", text="減衰カーブ")


class BONE_PT_tools(Panel):
    """ツールパネル"""
    bl_label = "ツール"
    bl_idname = "BONE_PT_bonesplitter_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BoneSplitter'
    bl_parent_id = "BONE_PT_bonesplitter_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        
        col = layout.column(align=True)
        col.operator("bonesplitter.mirror", text="ボーンをミラー", icon='MOD_MIRROR')
        col.operator("bonesplitter.cleanup_weights", text="ウェイトクリーンアップ", icon='BRUSH_DATA')


CLASSES = [
    BONE_PT_main,
    BONE_PT_settings,
    BONE_PT_tools,
]
