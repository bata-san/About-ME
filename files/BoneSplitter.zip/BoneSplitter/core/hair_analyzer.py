# core/hair_analyzer.py
# 髪の束の解析アルゴリズム

import bmesh
from mathutils import Vector
from typing import List, Tuple, Optional


class HairStrandAnalyzer:
    """髪の束を解析して最適なボーン配置を計算"""
    
    def __init__(self, mesh_obj, selected_vert_indices: List[int]):
        self.mesh_obj = mesh_obj
        self.matrix = mesh_obj.matrix_world
        self.vert_indices = selected_vert_indices
        
    def get_world_positions(self) -> List[Vector]:
        """選択された頂点のワールド座標を取得"""
        mesh = self.mesh_obj.data
        return [self.matrix @ mesh.vertices[i].co.copy() for i in self.vert_indices]
    
    def compute_center(self) -> Vector:
        """重心を計算"""
        positions = self.get_world_positions()
        if not positions:
            return Vector((0, 0, 0))
        return sum(positions, Vector()) / len(positions)
    
    def compute_principal_axis(self) -> Vector:
        """主軸（髪の流れ方向）を計算 - 簡易PCA"""
        positions = self.get_world_positions()
        if len(positions) < 2:
            return Vector((0, 0, -1))
        
        center = self.compute_center()
        
        # 共分散行列の近似として、最も離れた2点を結ぶ方向を使用
        max_dist = 0
        axis = Vector((0, 0, -1))
        
        for i, p1 in enumerate(positions):
            for p2 in positions[i+1:]:
                dist = (p2 - p1).length
                if dist > max_dist:
                    max_dist = dist
                    axis = (p2 - p1).normalized()
        
        # 下向きに正規化（髪は上から下に流れる）
        if axis.z > 0:
            axis = -axis
        
        return axis
    
    def compute_root_and_tip(self) -> Tuple[Vector, Vector]:
        """根元と先端を検出"""
        positions = self.get_world_positions()
        if len(positions) < 2:
            return Vector((0, 0, 0)), Vector((0, 0, -1))
        
        # Z座標でソート
        sorted_positions = sorted(positions, key=lambda p: p.z, reverse=True)
        
        # 上位10%の平均を根元、下位10%の平均を先端
        n = max(1, len(sorted_positions) // 10)
        
        root = sum(sorted_positions[:n], Vector()) / n
        tip = sum(sorted_positions[-n:], Vector()) / n
        
        return root, tip
    
    def compute_bone_positions(self, bone_count: int, smoothing: int = 0) -> List[Vector]:
        """ボーン配置位置を計算（軸投影＋スムージング）"""
        root, tip = self.compute_root_and_tip()
        positions = self.get_world_positions()
        
        # 最低限の頂点しかない場合は線形補間で終了
        if len(positions) < 3:
            return [root.lerp(tip, i / bone_count) for i in range(bone_count + 1)]
        
        axis = self.compute_principal_axis()
        if axis.length == 0:
            axis = Vector((0, 0, -1))
        origin = self.compute_center()
        
        # 頂点を軸方向に投影して並べ替え
        projected = [(((p - origin).dot(axis)), p) for p in positions]
        projected.sort(key=lambda x: x[0])
        scalars = [s for s, _ in projected]
        s_min, s_max = min(scalars), max(scalars)
        if abs(s_max - s_min) < 1e-6:
            return [root.lerp(tip, i / bone_count) for i in range(bone_count + 1)]
        
        # 各ボーン位置は投影スカラーの等間隔位置にある頂点の平均で決める
        window = (s_max - s_min) / max(bone_count * 1.5, 1.0)
        result = []
        for i in range(bone_count + 1):
            t = i / bone_count
            center_s = s_min + (s_max - s_min) * t
            samples = [p for s, p in projected if abs(s - center_s) <= window * 0.5]
            if not samples and smoothing > 0:
                # スムージング値に応じてウィンドウを少し広げる
                widen = window * (0.5 + 0.3 * smoothing)
                samples = [p for s, p in projected if abs(s - center_s) <= widen]
            if samples:
                avg = sum(samples, Vector()) / len(samples)
                result.append(avg)
            else:
                # フォールバックは単純な線形補間
                result.append(root.lerp(tip, t))
        
        # 追加スムージング（移動平均）
        for _ in range(max(0, smoothing)):
            if len(result) < 3:
                break
            smoothed = [result[0]]
            for j in range(1, len(result) - 1):
                smoothed.append((result[j - 1] + result[j] + result[j + 1]) / 3)
            smoothed.append(result[-1])
            result = smoothed
        
        return result
    
    def detect_side(self) -> str:
        """左右を判定（.L / .R / 空文字）"""
        center = self.compute_center()
        
        threshold = 0.01
        if center.x > threshold:
            return ".R"
        elif center.x < -threshold:
            return ".L"
        return ""


def get_selected_vert_indices(mesh_obj) -> List[int]:
    """編集モードで選択された頂点のインデックスを取得"""
    mesh = mesh_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    indices = [v.index for v in bm.verts if v.select]
    return indices


def save_selection_to_object_mode(mesh_obj) -> List[int]:
    """選択状態をオブジェクトモードに保存"""
    mesh = mesh_obj.data
    bm = bmesh.from_edit_mesh(mesh)
    indices = [v.index for v in bm.verts if v.select]
    
    # bmeshを更新
    bmesh.update_edit_mesh(mesh)
    
    return indices
