# core/properties.py
# プロパティ定義

import bpy
from bpy.props import (
    IntProperty,
    FloatProperty,
    StringProperty,
    BoolProperty,
)
from bpy.types import PropertyGroup


class BoneSplitterSettings(PropertyGroup):
    """アドオン設定"""
    
    # 命名設定
    prefix: StringProperty(
        name="プレフィックス",
        default="cc_hear",
    )
    
    chain_number: IntProperty(
        name="チェーン番号",
        default=1,
        min=1,
        max=999,
    )
    
    # ボーン設定
    bone_count: IntProperty(
        name="ボーン数",
        default=4,
        min=1,
        max=15,
    )
    
    parent_bone: StringProperty(
        name="親ボーン",
        default="",
    )
    
    # ウェイト設定
    auto_weight: BoolProperty(
        name="自動ウェイト",
        default=True,
    )
    
    weight_radius: FloatProperty(
        name="影響半径",
        default=0.02,
        min=0.001,
        max=0.5,
        precision=3,
    )

    smoothing: IntProperty(
        name="スムージング",
        description="ボーン配置を滑らかにする反復回数",
        default=1,
        min=0,
        max=5,
    )

    max_influences: IntProperty(
        name="最大影響ボーン",
        description="1頂点あたりの最大影響ボーン数",
        default=2,
        min=1,
        max=4,
    )

    distance_exponent: FloatProperty(
        name="減衰カーブ",
        description="距離減衰の鋭さ (大きいほどタイト)",
        default=2.0,
        min=0.5,
        max=4.0,
        precision=2,
    )


CLASSES = [
    BoneSplitterSettings,
]
