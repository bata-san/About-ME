# BoneSplitter - Hair Bone Generator for Blender 5.0
# 髪の毛用ボーン自動生成アドオン

bl_info = {
    "name": "BoneSplitter - Hair Bone Generator",
    "author": "BoneSplitter",
    "version": (2, 0, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > BoneSplitter",
    "description": "髪の毛用ボーンを自動生成し、ウェイトペイントまで一括処理",
    "category": "Rigging",
}

import bpy
from bpy.props import PointerProperty

from .core import properties, operators, panels


def register():
    """アドオン登録"""
    for cls in properties.CLASSES:
        bpy.utils.register_class(cls)
    for cls in operators.CLASSES:
        bpy.utils.register_class(cls)
    for cls in panels.CLASSES:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.bonesplitter = PointerProperty(type=properties.BoneSplitterSettings)
    print("BoneSplitter v2.0: 有効化")


def unregister():
    """アドオン登録解除"""
    del bpy.types.Scene.bonesplitter
    
    for cls in reversed(panels.CLASSES):
        bpy.utils.unregister_class(cls)
    for cls in reversed(operators.CLASSES):
        bpy.utils.unregister_class(cls)
    for cls in reversed(properties.CLASSES):
        bpy.utils.unregister_class(cls)
    
    print("BoneSplitter v2.0: 無効化")


if __name__ == "__main__":
    register()
